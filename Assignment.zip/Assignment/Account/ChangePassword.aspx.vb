﻿
Partial Class Account_ChangePassword
    Inherits System.Web.UI.Page

End Class
